package br.sprintdev.model.dao;

import java.util.List;

import br.sprintdev.model.entity.Team;

public interface TeamDao {

	void save(Team team);
	
	void update(Team team);
	
	void delete(Long id);
	
	Team findById(Long id);
	
	List<Team> findAll();
	
}
