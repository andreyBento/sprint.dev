package br.sprintdev.model.service;

import java.util.List;

import br.sprintdev.model.entity.Team;

public interface TeamService {

	void create(Team team);
	
	void update(Team team);
	
	void delete(Long id);
	
	Team findById(Long id);
	
	List<Team> findAll();
	
}
