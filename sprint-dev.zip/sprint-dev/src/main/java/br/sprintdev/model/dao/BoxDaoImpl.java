package br.sprintdev.model.dao;

import org.springframework.stereotype.Repository;

import br.sprintdev.model.entity.Box;

@Repository
public class BoxDaoImpl extends AbstractDao<Box, Long> implements BoxDao {

}
