package br.sprintdev.model.dao;

import org.springframework.stereotype.Repository;

import br.sprintdev.model.entity.Meeting;

@Repository
public class MeetingDaoImpl extends AbstractDao<Meeting, Long> implements MeetingDao {

}
