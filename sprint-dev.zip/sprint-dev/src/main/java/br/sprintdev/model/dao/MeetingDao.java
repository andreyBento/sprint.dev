package br.sprintdev.model.dao;

import java.util.List;

import br.sprintdev.model.entity.Meeting;

public interface MeetingDao {

	void save(Meeting meeting);
	
	void update(Meeting meeting);
	
	void delete(Long id);
	
	Meeting findById(Long id);
	
	List<Meeting> findAll();
	
}
