package br.sprintdev.model.dao;

import java.util.List;

import br.sprintdev.model.entity.Sprint;

public interface SprintDao {

	void save(Sprint sprint);
	
	void update(Sprint sprint);
	
	void delete(Long id);
	
	Sprint findById(Long id);
	
	List<Sprint> findAll();
	
}
