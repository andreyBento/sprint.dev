package br.sprintdev.model.entity;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@SuppressWarnings("serial")
@Entity
@Table(name = "MEETINGS")
public class Meeting extends AbstractEntity<Long> {
	
	private String name;
	
	private String desc;
	
	@NotNull
	@ManyToOne
	@JoinColumn(name = "owner_id")
	private Sprint owner;
	
	@NotNull
	@DateTimeFormat(iso = ISO.DATE, pattern = "")
	private LocalDate when;
	
	@ManyToMany
	@JoinTable(
			  name = "meeting_teams", 
			  joinColumns = @JoinColumn(name = "meeting_id"), 
			  inverseJoinColumns = @JoinColumn(name = "team_id"))
	private List<Team> teams;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Sprint getOwner() {
		return owner;
	}

	public void setOwner(Sprint owner) {
		this.owner = owner;
	}

	public LocalDate getWhen() {
		return when;
	}

	public void setWhen(LocalDate when) {
		this.when = when;
	}

	public List<Team> getTeams() {
		return teams;
	}

	public void setTeams(List<Team> teams) {
		this.teams = teams;
	}

}
