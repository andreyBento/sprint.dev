package br.sprintdev.model.dao;

import org.springframework.stereotype.Repository;

import br.sprintdev.model.entity.Comment;

@Repository
public class CommentDaoImpl extends AbstractDao<Comment, Long> implements CommentDao {

}
