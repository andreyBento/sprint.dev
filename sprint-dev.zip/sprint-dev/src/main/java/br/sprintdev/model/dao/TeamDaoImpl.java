package br.sprintdev.model.dao;

import org.springframework.stereotype.Repository;

import br.sprintdev.model.entity.Team;

@Repository
public class TeamDaoImpl extends AbstractDao<Team, Long> implements TeamDao {

}
