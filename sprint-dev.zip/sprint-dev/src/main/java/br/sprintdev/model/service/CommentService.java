package br.sprintdev.model.service;

import java.util.List;

import br.sprintdev.model.entity.Comment;

public interface CommentService {
	
	void create(Comment comment);
	
	void update(Comment comment);
	
	void delete(Long id);
	
	Comment findById(Long id);
	
	List<Comment> findAll();

}
