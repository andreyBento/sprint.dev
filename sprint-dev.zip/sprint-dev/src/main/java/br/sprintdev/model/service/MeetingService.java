package br.sprintdev.model.service;

import java.util.List;

import br.sprintdev.model.entity.Meeting;

public interface MeetingService {

	void create(Meeting meeting);
	
	void update(Meeting meeting);
	
	void delete(Long id);
	
	Meeting findById(Long id);
	
	List<Meeting> findAll();
	
}
